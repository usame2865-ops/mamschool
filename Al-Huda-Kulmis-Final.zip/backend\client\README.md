# Frontend Setup

Recommended packages:

npm install react-router-dom axios react-icons

Why:
- react-router-dom → page routing
- axios → HTTP requests
- react-icons → UI icons
