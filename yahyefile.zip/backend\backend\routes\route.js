// Collect and organize all your API endpoints here
